function result = spectre(NFFT,Fs,impulses,T)

[a1,a2,a3] = split_impulses(impulses);
A = [a1(:).'; a2(:).'; a3(:).'];

[f,Glin,GdB] = calc_spectrum_norm(A,NFFT,Fs);

Gtheory = (sinc(f*T)).^2;
Gtheory = Gtheory./max(Gtheory + eps);
GdBtheory = 10*log10(Gtheory + eps);

figure;
plot(f, GdBtheory,'-','LineWidth',2,'DisplayName','теория'); hold on
plot(f, GdB(:,1),'--','LineWidth',2,'DisplayName','моделирование');
legend('show')
xlabel('{\itf}, 1/{\itT}')
ylabel('{\itG}({\itf})/{\itG}(0), дБ')
grid on
xlim([-10,10])
ylim([-90,5])

figure;
plot(f, GdB(:,1),'LineWidth',1.6,'DisplayName','n=0'); hold on
plot(f, GdB(:,2),'LineWidth',1.6,'DisplayName','n=1');
plot(f, GdB(:,3),'LineWidth',1.6,'DisplayName','n=11');
legend('show')
xlabel('{\itf}, 1/{\itT}')
ylabel('{\itG}({\itf})/{\itG}(0), дБ')
grid on
xlim([-10,10])
ylim([-90,5])

n = [0;1;11];
perviy_nul = [find_first_null(f,Glin(:,1)); find_first_null(f,Glin(:,2)); find_first_null(f,Glin(:,3))];
tabla_nul = table(n,perviy_nul,'VariableNames',{'n','perviy_nul_1_na_T'});
disp('Первый нуль спектра:')
disp(tabla_nul)

urovni_db = [-20;-30;-40;-60];
deltaF = zeros(numel(urovni_db),3);
for i = 1:numel(urovni_db)
    deltaF(i,1) = bandwidth_by_level(f,GdB(:,1),urovni_db(i));
    deltaF(i,2) = bandwidth_by_level(f,GdB(:,2),urovni_db(i));
    deltaF(i,3) = bandwidth_by_level(f,GdB(:,3),urovni_db(i));
end
tabla_db = table(urovni_db,deltaF(:,1),deltaF(:,2),deltaF(:,3), ...
    'VariableNames',{'uroven_dB','deltaF_n0','deltaF_n1','deltaF_n11'});
disp('Полоса по уровню спектра:')
disp(tabla_db)

share = [0.90;0.95;0.99];
deltaE = zeros(numel(share),3);
for i = 1:numel(share)
    deltaE(i,1) = bandwidth_by_energy(f,Glin(:,1),share(i));
    deltaE(i,2) = bandwidth_by_energy(f,Glin(:,2),share(i));
    deltaE(i,3) = bandwidth_by_energy(f,Glin(:,3),share(i));
end
tabla_e = table(share*100,deltaE(:,1),deltaE(:,2),deltaE(:,3), ...
    'VariableNames',{'koncentraciya_pct','deltaF_n0','deltaF_n1','deltaF_n11'});
disp('Полоса по концентрации энергии:')
disp(tabla_e)

result.f = f;
result.Glin = Glin;
result.GdB = GdB;
result.Gtheory = Gtheory;
result.tabla_nul = tabla_nul;
result.tabla_db = tabla_db;
result.tabla_e = tabla_e;

end

function [a1,a2,a3] = split_impulses(impulses)
if isvector(impulses)
    v = impulses(:).';
    m = numel(v);
    sps = floor(m/3);
    a1 = v(1:sps);
    a2 = v(sps+1:2*sps);
    a3 = v(2*sps+1:3*sps);
    return
end

[r,c] = size(impulses);
if c == 3
    a1 = impulses(:,1).';
    a2 = impulses(:,2).';
    a3 = impulses(:,3).';
elseif r == 3
    a1 = impulses(1,:);
    a2 = impulses(2,:);
    a3 = impulses(3,:);
else
    error('Неверный формат impulses')
end
end

function [f,Glin,GdB] = calc_spectrum_norm(A,NFFT,Fs)
f = (-NFFT/2:NFFT/2-1)*Fs/NFFT;
Glin = zeros(NFFT,3);
GdB = zeros(NFFT,3);
for k = 1:3
    S = fftshift(fft(A(k,:),NFFT));
    G = abs(S).^2;
    m = max(G);
    if m <= 0
        m = 1;
    end
    G = G./m;
    Glin(:,k) = G(:);
    GdB(:,k) = 10*log10(G(:)+eps);
end
end

function f0 = find_first_null(f,G)
[~,c] = min(abs(f));
g = G(:);
ff = f(:);
f0 = NaN;
for i = c+2:numel(g)-1
    if g(i-1) > g(i) && g(i+1) > g(i)
        f0 = abs(ff(i));
        return
    end
end
end

function dF = bandwidth_by_level(f,GdB,level_dB)
g = GdB(:);
ff = f(:);
[~,c] = min(abs(ff));
iCross = NaN;
for i = c:numel(g)-1
    if g(i) >= level_dB && g(i+1) < level_dB
        iCross = i;
        break
    end
end
if isnan(iCross)
    dF = NaN;
    return
end
f1 = ff(iCross); g1 = g(iCross);
f2 = ff(iCross+1); g2 = g(iCross+1);
if abs(g2-g1) < 1e-12
    fEdge = f1;
else
    fEdge = f1 + (level_dB-g1)*(f2-f1)/(g2-g1);
end
dF = 2*abs(fEdge);
end

function dF = bandwidth_by_energy(f,G,target_share)
ff = f(:);
g = G(:);
Etot = trapz(ff,g);
if Etot <= 0
    dF = NaN;
    return
end
[~,c] = min(abs(ff));
kMax = min(c-1, numel(ff)-c);
dF = NaN;
for k = 0:kMax
    iL = c-k;
    iR = c+k;
    Ewin = trapz(ff(iL:iR),g(iL:iR));
    if Ewin/Etot >= target_share
        dF = ff(iR)-ff(iL);
        return
    end
end
end
