if ~exist('impulses','var')
    error('Нет переменной impulses')
end

[a1,a2,a3] = split_impulses_pf(impulses);

r1 = calc_pik_factor(a1);
r2 = calc_pik_factor(a2);
r3 = calc_pik_factor(a3);

name = {'n=0';'n=1';'n=11'};
Pmax = [r1.Pmax; r2.Pmax; r3.Pmax];
Pmean = [r1.Pmean; r2.Pmean; r3.Pmean];
PikFactor = [r1.PikFactor; r2.PikFactor; r3.PikFactor];
PikFactordB = [r1.PikFactordB; r2.PikFactordB; r3.PikFactordB];

tabla_pik = table(name,Pmax,Pmean,PikFactor,PikFactordB);
disp('Пик-фактор:')
disp(tabla_pik)

if exist('t','var') && numel(t) == numel(a1)
    tx = t(:).';
else
    tx = linspace(0,1,numel(a1));
end

figure;
subplot(3,1,1); plot(tx,abs(a1).^2,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('p(t)'); title('n=0'); grid on
subplot(3,1,2); plot(tx,abs(a2).^2,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('p(t)'); title('n=1'); grid on
subplot(3,1,3); plot(tx,abs(a3).^2,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('p(t)'); title('n=11'); grid on

function [a1,a2,a3] = split_impulses_pf(imp)
if isvector(imp)
    v = imp(:).';
    m = numel(v);
    sps = floor(m/3);
    a1 = v(1:sps);
    a2 = v(sps+1:2*sps);
    a3 = v(2*sps+1:3*sps);
    return
end
[r,c] = size(imp);
if c == 3
    a1 = imp(:,1).';
    a2 = imp(:,2).';
    a3 = imp(:,3).';
elseif r == 3
    a1 = imp(1,:);
    a2 = imp(2,:);
    a3 = imp(3,:);
else
    error('Неверный формат impulses')
end
end
