function result = generate_impulse(t,T)

n = [0,1,11];

a1 = (sin(pi*t/T)).^n(1);
a2 = (sin(pi*t/T)).^n(2);
a3 = (sin(pi*t/T)).^n(3);
result = [a1,a2,a3];

figure;
subplot(3,1,1); plot(t/T,a1,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('{\ita}({\itt})'); title('n=0'); grid on
subplot(3,1,2); plot(t/T,a2,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('{\ita}({\itt})'); title('n=1'); grid on
subplot(3,1,3); plot(t/T,a3,'LineWidth',1.2); xlabel('{\itt}/{\itT}'); ylabel('{\ita}({\itt})'); title('n=11'); grid on

end
