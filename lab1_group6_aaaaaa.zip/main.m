clc; clear; close all;

T = 1;
sps = 100;
dt = T/sps;
t = 0:dt:T-dt;

Nfft = 2^14;
Fs = sps/T;

impulses = generate_impulse(t,T);
spectr = spectre(Nfft,Fs,impulses,T);

part3_pikfactor_LR1
