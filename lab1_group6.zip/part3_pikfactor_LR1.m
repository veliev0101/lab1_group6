if ~exist('impulses','var')
    error('Нет переменной impulses')
end

if isvector(impulses)
    L = numel(impulses)/3;
    a1 = impulses(1:L);
    a2 = impulses(L+1:2*L);
    a3 = impulses(2*L+1:3*L);
else
    a1 = impulses(:,1);
    a2 = impulses(:,2);
    a3 = impulses(:,3);
end

r1 = calc_pik_factor(a1);
r2 = calc_pik_factor(a2);
r3 = calc_pik_factor(a3);

name = {'n=0';'n=1';'n=11'};
Pmax = [r1.Pmax; r2.Pmax; r3.Pmax];
Pmean = [r1.Pmean; r2.Pmean; r3.Pmean];
PikFactor = [r1.PikFactor; r2.PikFactor; r3.PikFactor];
PikFactordB = [r1.PikFactordB; r2.PikFactordB; r3.PikFactordB];

tabla_pik = table(name,Pmax,Pmean,PikFactor,PikFactordB);
disp('Пик-фактор:')
disp(tabla_pik)
